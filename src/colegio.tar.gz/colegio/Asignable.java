package colegio;

public interface Asignable {
   
    // Los métodos de una interfaz son públicos por defecto
    void asignarTutoría (Escolarizable.Curso curso);
    void asignarJefatura (boolean asignada);
    
}
